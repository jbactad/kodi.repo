from resources.lib.yify.routes import plugin

if __name__ == '__main__':
    plugin.run()
