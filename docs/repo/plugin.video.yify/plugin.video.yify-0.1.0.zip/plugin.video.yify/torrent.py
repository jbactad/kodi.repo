# coding: utf-8
# Module: server
# Created on: 01.07.2015
# Author: Roman Miroshnychenko aka Roman V.M. (romanvm@yandex.ua)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Torrent streamer WSGI server
"""

from xbmcswift2 import xbmc, xbmcgui

monitor = xbmc.Monitor()
if monitor.waitForAbort(2.0):
    raise SystemExit

from resources.lib.torrent.wsgi_server import create_server
from resources.lib.torrent.plugin import Plugin

plugin = Plugin()
_ = plugin.get_string
plugin.notify(msg='Starting Torrent Server...')

# A monkey-patch to set the necessary librorrent version
librorrent_addon = Plugin(addon_id='script.module.libtorrent')
orig_custom_version = librorrent_addon.get_setting('custom_version')
orig_set_version = librorrent_addon.get_setting('set_version')
librorrent_addon.set_setting('custom_version', 'true')
if plugin.libtorrent_version == '1.0.9':
    librorrent_addon.set_setting('set_version', '4')
elif plugin.libtorrent_version == '1.1.0':
    librorrent_addon.set_setting('set_version', '5')
elif plugin.libtorrent_version == '1.1.1':
    librorrent_addon.set_setting('set_version', '6')
else:
    librorrent_addon.set_setting('set_version', '0')

from resources.lib.torrent import wsgi_app

librorrent_addon.set_setting('custom_version', orig_custom_version)
librorrent_addon.set_setting('set_version', orig_set_version)
# ======

if plugin.enable_limits:
    wsgi_app.limits_timer.start()
if plugin.persistent:
    wsgi_app.save_resume_timer.start()
httpd = create_server(wsgi_app.app, port=plugin.server_port)
httpd.timeout = 0.1
start_trigger = True
while not monitor.abortRequested():
    httpd.handle_request()
    if start_trigger:
        plugin.notify(msg='Torrent Server started')
        xbmcgui.Dialog().notification('YATP', _('32028'), plugin.icon, 3000, False)
        start_trigger = False
plugin.log.debug(msg='Stopping Torrent Server...')
plugin.log.debug('Close server socket')
httpd.socket.close()
plugin.log.debug('Abort buffering')
wsgi_app.torrent_client.abort_buffering()
plugin.log.debug('Stop timers')
if plugin.enable_limits:
    wsgi_app.limits_timer.abort()
if plugin.persistent:
    wsgi_app.save_resume_timer.abort()
plugin.notify(msg='Torrent Server stopped')
