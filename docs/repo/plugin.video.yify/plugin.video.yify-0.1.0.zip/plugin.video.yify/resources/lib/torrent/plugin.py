import os
import sys

from xbmcswift2 import xbmc, Plugin as BasePlugin


class Plugin(BasePlugin):

    @property
    def credentials(self):
        return self.get_setting(key='web_login'), self.get_setting(key='web_pass')

    @property
    def download_dir(self):
        d_dir = self.get_setting('download_dir') or xbmc.translatePath('special://temp')
        if sys.platform == 'win32':
            d_dir = d_dir.decode('utf-8')
        if not os.path.exists(d_dir):
            os.mkdir(d_dir)
        return d_dir

    @property
    def path(self):
        return self.addon.getAddonInfo('path')

    @property
    def icon(self):
        return self.addon.getAddonInfo('icon')

    @property
    def expired_action(self):
        return self.get_setting(key='expired_action')

    @property
    def delete_expired_files(self):
        return self.get_setting(key='delete_expired_files')

    @property
    def torrent_port(self):
        return self.get_setting(key='torrent_port', converter=int)

    @property
    def persistent(self):
        return self.get_setting(key='persistent')

    @property
    def dl_speed_limit(self):
        return self.get_setting(key='dl_speed_limit', converter=int)

    @property
    def ul_speed_limit(self):
        return self.get_setting(key='ul_speed_limit', converter=int)

    @property
    def connections_limit(self):
        return self.get_setting(key='connections_limit', converter=int)

    @property
    def half_open_limit(self):
        return self.get_setting(key='half_open_limit', converter=int)

    @property
    def unchoke_slots_limit(self):
        return self.get_setting(key='unchoke_slots_limit', converter=int)

    @property
    def file_pool_size(self):
        return self.get_setting(key='file_pool_size', converter=int)

    @property
    def connection_speed(self):
        return self.get_setting(key='connection_speed', converter=int)

    @property
    def enable_encryption(self):
        return self.get_setting(key='enable_encryption')

    @property
    def enable_limits(self):
        return self.get_setting(key='enable_limits')

    @property
    def libtorrent_version(self):
        return self.get_setting(key='libtorrent_version')

    @property
    def server_port(self):
        return self.get_setting(key='server_port', converter=int)

    @property
    def ratio_limit(self):
        return self.get_setting(key='ratio_limit', converter=int)

    @property
    def time_limit(self):
        return self.get_setting(key='time_limit', converter=int)

    @property
    def buffer_duration(self):
        return self.get_setting(key='buffer_duration', converter=int)

    @property
    def sliding_window_length(self):
        return self.get_setting(key='sliding_window_length', converter=int)

    @property
    def default_buffer_size(self):
        return self.get_setting(key='default_buffer_size', converter=int)

    @property
    def pass_protect(self):
        return self.get_setting(key='pass_protect')

    @property
    def pause_timeout(self):
        return self.get_setting(key='pause_timeout')
