from os import path

from xbmcswift2 import Plugin as BasePlugin

sort_method_map = {
    'Title': 'title',
    'Year': 'year',
    'Rating': 'rating',
    'Peers': 'peers',
    'Seeds': 'seeds',
    'Download Count': 'download_count',
    'Like Count': 'like_count',
    'Date Added': 'date_added',
}


class Plugin(BasePlugin):
    @property
    def path(self):
        return self.addon.getAddonInfo('path')

    @property
    def icon(self):
        return self.addon.getAddonInfo('icon')

    def get_icon_path(self, filename):
        return path.join(self.path, 'resources', 'icons', filename)

    def get_arg(self, key):
        if type(self.request.args[key]) is list:
            return self.request.args[key][0]
        else:
            return self.request.args[key]

    def has_arg(self, key):
        return key in self.request.args

    @property
    def quality(self):
        return self.get_setting(key='quality', converter=str)

    @property
    def sort_by(self):
        sort = self.get_setting(key='sort', converter=str)
        return self.get_sort_value(sort)

    @property
    def min_rating(self):
        return self.get_setting(key='min_rating', converter=int)

    @property
    def page_limit(self):
        return self.get_setting(key='page_limit', converter=int)

    @staticmethod
    def get_sort_value(s):
        return sort_method_map[s]

    @property
    def server_port(self):
        return self.get_setting(key='server_port', converter=int)
