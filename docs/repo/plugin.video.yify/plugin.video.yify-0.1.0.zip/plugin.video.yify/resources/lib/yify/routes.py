import os

from xbmcswift2 import xbmcgui

import json_requests as jsonrq
from buffering import get_videofiles, stream_torrent, add_torrent
from plugin import Plugin
from yts import YTSClient

plugin = Plugin()
_ = plugin.get_string
yts_client = YTSClient(plugin=plugin)
commands = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'commands.py')


@plugin.route('/')
def index():
    items = [{
        'label': _(stringid='30003'),
        'path': plugin.url_for(browse),
    }, {
        'label': _(stringid='30004'),
        'path': plugin.url_for(browse_genres),
    }, {
        'label': _(stringid='30048'),
        'path': plugin.url_for(downloaded_movies),
    }]

    return plugin.finish(items=items)


@plugin.route('/browse')
def browse():
    page = 1
    genre = ''
    if plugin.has_arg('page'):
        page = plugin.get_arg('page')

    if plugin.has_arg('genre'):
        genre = plugin.get_arg('genre')

    movies = yts_client.list_movies(quality=plugin.quality, genre=genre, minimum_rating=plugin.min_rating, page=page,
                                    sort_by=plugin.sort_by, limit=plugin.page_limit)

    items = [{
        'label': m['title_long'],
        'label2': m['title'],
        'path': plugin.url_for(get_movie_details, movie_id=m['id']),
        'icon': m['small_cover_image'],
        'thumbnail': m['medium_cover_image'],
        'stream_info': {
            'duration': m['runtime'],
        },
        'info': {
            'imdbnumber': m['imdb_code'],
            'year': m['year'],
            'genre': m['genres'],
            'duration': m['runtime'],
            'sorttitle': m['title'],
            'plot': m['description_full'],
            'plotoutline': m['summary'],
            'rating': m['rating'],
        },
    } for m in movies]

    if int(page) > 1:
        items.insert(0, {
            'label': '<< %s' % (_(stringid='30001')),
            'path': plugin.url_for(browse, quality=plugin.quality, genre=genre, min_rating=plugin.min_rating,
                                   sort_by=plugin.sort_by, limit=plugin.page_limit, page=int(page) - 1)
        })

    items.append({
        'label': '%s >>' % (_(stringid='30002')),
        'path': plugin.url_for(browse, quality=plugin.quality, genre=genre, min_rating=plugin.min_rating,
                               sort_by=plugin.sort_by, limit=plugin.page_limit, page=int(page) + 1),
    })

    return plugin.finish(items=items)


@plugin.route('/movie/genres')
def browse_genres():
    items = [{
        'label': _(stringid=g),
        'path': plugin.url_for(browse, genre=_(stringid=g))
    } for g in YTSClient.get_genres()]

    return plugin.finish(items=items)


@plugin.route('/movie/<movie_id>')
def get_movie_details(movie_id):
    movie_info = get_movie_info(movie_id)

    items = [{
        'label': movie_info['title_long'] + " " + torrent['quality'],
        'label2': movie_info['title'] + " " + torrent['quality'],
        'path': plugin.url_for(select_torrent, torrent=torrent['url'], action='play'),
        'icon': movie_info['small_cover_image'],
        'thumbnail': movie_info['medium_cover_image'],
        'stream_info': {
            'duration': movie_info['runtime'],
        },
        'info': {
            'imdbnumber': movie_info['imdb_code'],
            'year': movie_info['year'],
            'genre': movie_info['genres'],
            'duration': movie_info['runtime'],
            'sorttitle': movie_info['title'],
            'plot': movie_info['description_full'],
            'plotoutline': movie_info['description_intro'],
            'rating': movie_info['rating'],
        },
    } for torrent in movie_info['torrents']]

    return plugin.finish(items=items)


@plugin.cached()
def get_movie_info(movie_id):
    movie_info = yts_client.movie_details(movie_id)
    return movie_info


@plugin.route('/downloaded_movies')
def downloaded_movies():
    torrent_list = sorted(jsonrq.get_all_torrent_info(), key=lambda i: i['added_time'], reverse=True)
    for torrent in torrent_list:
        if torrent['state'] == 'downloading':
            label = '[COLOR=red]{0}[/COLOR]'.format(torrent['name'].encode('utf-8'))
        elif torrent['state'] == 'seeding':
            label = '[COLOR=green]{0}[/COLOR]'.format(torrent['name'].encode('utf-8'))
        elif torrent['state'] == 'paused':
            label = '[COLOR=gray]{0}[/COLOR]'.format(torrent['name'].encode('utf-8'))
        else:
            label = '[COLOR=blue]{0}[/COLOR]'.format(torrent['name'].encode('utf-8'))

        item = {'label': label,
                'path': plugin.url_for(show_files, info_hash=torrent['info_hash']),
                }

        if torrent['state'] == 'downloading':
            item['thumbnail'] = plugin.get_icon_path('down.png')
        elif torrent['state'] == 'seeding':
            item['thumbnail'] = plugin.get_icon_path('up.png')
        elif torrent['state'] == 'paused':
            item['thumbnail'] = plugin.get_icon_path('pause.png')
        else:
            item['thumbnail'] = plugin.get_icon_path('question.png')

        context_menu = [(_('32005'),
                         'RunScript({commands},pause_all)'.format(commands=commands)),
                        (_('32006'),
                         'RunScript({commands},resume_all)'.format(commands=commands)),
                        (_('32007'),
                         'RunScript({commands},delete,{info_hash})'.format(commands=commands,
                                                                           info_hash=torrent['info_hash'])),
                        (_('32008'),
                         'RunScript({commands},delete_with_files,{info_hash})'.format(commands=commands,
                                                                                      info_hash=torrent[
                                                                                          'info_hash'])),
                        (_('32065'),
                         'RunScript({commands},show_info,{info_hash})'.format(commands=commands,
                                                                              info_hash=torrent['info_hash'])),
                        ]

        if torrent['state'] == 'paused':
            context_menu.insert(0, (_('32009'),
                                    'RunScript({commands},resume,{info_hash})'.format(commands=commands,
                                                                                      info_hash=torrent[
                                                                                          'info_hash'])))
        else:
            context_menu.insert(0, (_('32010'),
                                    'RunScript({commands},pause,{info_hash})'.format(commands=commands,
                                                                                     info_hash=torrent[
                                                                                         'info_hash'])))
        if torrent['state'] == 'incomplete':
            context_menu.append((_('32066'),
                                 'RunScript({commands},restore_finished,{info_hash})'.format(
                                     commands=commands,
                                     info_hash=torrent['info_hash'])))

        item['context_menu'] = context_menu
        yield item


@plugin.route('/show_files/<info_hash>')
def show_files(info_hash):
    return plugin.finish(_build_file_list(jsonrq.get_files(info_hash), info_hash))


@plugin.route('/play_file/<info_hash>/<file_index>')
def play_file(info_hash, file_index):
    return plugin.set_resolved_url(stream_torrent(int(file_index), info_hash))


@plugin.route('/select_torrent/<action>/<torrent>')
def select_torrent(action='download', torrent=None):
    plugin.log.debug('select_torrent/%s/%s' % (action, torrent))
    if not torrent:
        torrent = xbmcgui.Dialog().browse(1, _('32003'), 'video', mask='.torrent')

    if torrent:
        plugin.notify(msg='Torrent selected: {0}'.format(torrent))
        if action == 'play':
            return list_files(torrent)
        else:
            return plugin.set_resolved_url(item=plugin.url_for(download_torrent, torrent=torrent))


# @plugin.route('/list_files/<torrent>')
def list_files(torrent):
    torrent_data = add_torrent(torrent)
    if torrent_data is not None:
        return plugin.finish(items=_build_file_list(torrent_data['files'], torrent_data['info_hash']))

    xbmcgui.Dialog().notification(plugin.id, _('32023'), plugin.icon, 3000)

    return plugin.finish([])


@plugin.route('/download_torrent/<torrent>')
def download_torrent(torrent):
    jsonrq.add_torrent(torrent, False)
    xbmcgui.Dialog().notification('Yify', _('32004'), plugin.icon, 3000)


def _build_file_list(files, info_hash):
    video_files = get_videofiles(files)

    for file_ in video_files:
        ext = os.path.splitext(file_[1].lower())[1]
        if ext == '.avi':
            thumb = plugin.get_icon_path('avi.png')
        elif ext == '.mp4':
            thumb = plugin.get_icon_path('mp4.png')
        elif ext == '.mkv':
            thumb = plugin.get_icon_path('mkv.png')
        elif ext == '.mov':
            thumb = plugin.get_icon_path('mov.png')
        else:
            thumb = plugin.get_icon_path('play.png')
        yield {'label': '{name} [{size}{unit}]'.format(name=file_[1].encode('utf-8'),
                                                       size=file_[2] / 1048576,
                                                       unit=_('32067')),
               'thumbnail': thumb,
               'path': plugin.url_for(play_file, info_hash=info_hash, file_index=file_[0]),
               'is_playable': True,
               'info': {'size': file_[2]},
               }
