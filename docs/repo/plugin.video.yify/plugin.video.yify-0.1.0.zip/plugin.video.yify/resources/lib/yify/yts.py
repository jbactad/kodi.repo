from httplib import HTTPConnection

import requests
from requests import Session

from plugin import Plugin


class YTSClient:
    base_url = 'https://yts.am/api/v2/'
    default_header = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) '
                      'AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/74.0.3729.169 Safari/537.36 '
    }
    trackers = [
        'udp://open.demonii.com:1337/announce',
        'udp://tracker.openbittorrent.com:80',
        'udp://tracker.coppersurfer.tk:6969',
        'udp://glotorrents.pw:6969/announce',
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://torrent.gresille.org:80/announce',
        'udp://p4p.arenabg.com:1337',
        'udp://tracker.leechers-paradise.org:6969',
    ]
    _plugin = None  # type: Plugin

    def __init__(self, plugin, base_url=None, default_header=None, add_trackers=()):
        self._plugin = plugin
        self._session = Session()

        if base_url is not None:
            self.base_url = base_url
        if default_header is not None:
            self.default_header = default_header
        if not add_trackers:
            self.trackers.append(add_trackers)

        self._session.headers = self.default_header
        # HTTPConnection.debuglevel = self._plugin.log.level

    def list_movies(self, limit=20, page=1, quality='All', minimum_rating=0, query_term='0', genre='',
                    sort_by='date_added',
                    order_by='desc', with_rt_ratings=False):
        payload = {
            'limit': limit,
            'page': page,
            'quality': quality,
            'minimum_rating': minimum_rating,
            'query_term': query_term,
            'genre': genre,
            'sort_by': sort_by,
            'order_by': order_by,
            'with_rt_ratings': with_rt_ratings,
        }
        response = self._session.get(url=self.base_url + 'list_movies.json', params=payload).json()
        return response['data']['movies'] if 'data' in response and 'movies' in response['data'] else []

    def movie_details(self, movie_id, with_images=False, with_cast=False):
        payload = {
            'movie_id': movie_id,
            'with_images': with_images,
            'with_cast': with_cast,
        }
        response = self._session.get(url=self.base_url + 'movie_details.json', params=payload).json()

        return response['data']['movie']

    def generate_magnet_url(self, torrent_hash, name):
        magnet_url = 'magnet:?xt=urn:btih:%s&dn=%s' % (torrent_hash, requests.utils.quote(name))
        magnet_url = magnet_url + ''.join(['&tr=' + t for t in self.trackers])

        return magnet_url

    @staticmethod
    def encode(val):
        return requests.utils.quote(val)

    @staticmethod
    def get_genres():
        return range(30007, 30032 + 1)

    @staticmethod
    def get_ratings():
        return range(0, 9)
